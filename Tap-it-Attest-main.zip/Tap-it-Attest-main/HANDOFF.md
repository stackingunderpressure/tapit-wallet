# HANDOFF.md

State of the repo as of the last commit on
`claude/review-codebase-Ou5Hd`. Update this file whenever you finish
a session so the next agent can pick up exactly where you stopped.
Read `CLAUDE.md` first, then this.

## Current state

- **Branch**: `claude/review-codebase-Ou5Hd` (pushed).
- **Library version**: `0.1.1`. Tests 49/49 green; typecheck and
  lint clean.
- **DESIGN.md**: 27 locked decisions (D1–D27); 4 still-open
  questions (Q3, Q5, Q16, Q17); 2 future directions (F1, F2 — AI
  agent layer, deferred from v1).
- **No wallet code yet.** Only the library exists.

## What just happened (chronological)

1. Drafted `DESIGN.md` end-to-end: kept the library as-is, added the
   wallet/group/recovery/governance design on top.
2. Walked through 4 rounds of locking decisions (D1–D27).
3. Opened `tapit-attest-quorum.zip` — turned out to be **not** a
   quorum module. It's a 0.1.1 patch of the same library with one
   real fix to `sign.ts` (appended bad signatures no longer poison a
   genuine envelope) plus a regression test. Misleading filename.
4. Verified the patch is safe (every caller of `verifyEnvelope`
   already wants the new semantics; the revocation error message
   literally says "no valid signature"). Applied it, bumped version
   to 0.1.1, added the regression test. Tests still 49/49 green.

## Next track (picked, not started)

Write `DATA_MODEL.md` — the wallet data model spec. Formalize every
entity the wallet needs beyond what the library already provides:

- `Group` — internal key, charter ref, current tree ref, durability
  config (D20), founding event.
- `Charter` — versioned free-text + signed amendment chain (D13, D22).
- `TreeAmendment` — append-only log of taproot-tree state changes
  (D14, D17).
- `Membership` — leaf key + Merkle path + member metadata.
- `Candidacy` / `Objection` — silent-window admission (D19).
- `RelayPointer` — signed pointer to a group's relay (D8).
- `Custody` — custodian binding for a held child key (D1).
- `WeightPolicy` — concrete shape of the `WeightTable` per D26/D27,
  plus categories, per-edge overrides, hop limit.
- `Peer` — recovery responder binding (D6) + handshake state.
- `Contact` — counterparty record (pubkey + assigned category +
  weight override + nickname).
- `InboxItem` — discriminated union for D11's unified feed
  (incoming envelope, outgoing, draft, candidacy, objection,
  amendment, anchor confirmation, recovery request).
- Indexing strategy — subject-keyed, kind-keyed, contact-keyed
  views; what's denormalized vs derived.

Output is a single markdown spec at `DATA_MODEL.md`. Code comes
later. Keep it self-consistent with the decisions in `DESIGN.md`;
flag any contradiction surfaced during the drafting as a new Q.

## Open considerations to look at while there

These came up but weren't resolved. Worth a look during data-model
work or separately.

### Slip caught: `computeWeight` unknown-signer default vs D26

`src/core/weighting.ts:42` defaults unknown signers to **weight 1**:
```
const w = table.get(signer) ?? 1;
```
with the comment "so an attestation is never silently worth zero."

D26 locks the wallet's default for `stranger` at **0.0**. These
disagree.

Three ways to reconcile:
1. The wallet always builds a complete `WeightTable` so the `?? 1`
   fallback is never hit. Library unchanged.
2. `computeWeight` gains an `unknownDefault` option; wallet passes
   `0`. Library minor API addition.
3. Library default flips to 0. Riskier — other integrators of
   the library may rely on the current "never silently zero" rule.

Lean: **option 2** (small, opt-in, no behavior change for existing
callers). Surface during data-model work since `WeightPolicy` is
where the wallet's policy lives.

### Housekeeping
- `tapit-attest-quorum.zip` is now absorbed; can be deleted from
  the repo when convenient.
- `.gitignore` does not list `package-lock.json`; it shows up as
  untracked every `npm install`. Add to `.gitignore` if the
  no-lock-file convention is staying.

## Other ready-to-go tracks (if you want to switch)

In rough order of leverage:

1. **`DATA_MODEL.md`** — picked above. Highest leverage.
2. **`NFC.md`** — wire-level choreography for D24/D25 (context-aware
   tap, tap-to-cosign). Frame format, draft-hash compare, signature
   handoff, failure modes. Self-contained.
3. **`GROUP_TREE.md`** — pick crypto libraries for Schnorr /
   FROST / MuSig2 / Merkle (we already have `@noble/curves`).
   Specify the amendment-event format and the verifier for
   script-path signatures.
4. **Wallet scaffold** — new top-level directory, React/TS + Vite
   PWA shell + Tauri stub, skeleton routes for inbox + contacts +
   groups + settings. Big commit; benefits from `DATA_MODEL.md`
   landing first.

## Still-open questions in `DESIGN.md`

- **Q3** Peer / relay discovery (leaning "social + explicit" for v0).
- **Q5** Repudiation flow (deferred to v1.1).
- **Q16** Silent-window admission tightening (D19): objection
  threshold, who triggers the auto-amendment on window close.
- **Q17** Leaf-key rotation slot semantics (D23).

## Decision register

Locked: D1–D27. See `DESIGN.md` "Locked decisions" for the full
text and rationale. Each `Dn` is referenced from later docs as the
source of truth.

## How to update this file

When you finish a session: prepend or replace the "What just
happened" and "Next track" sections; move resolved items out;
preserve "Slip caught" entries until they're addressed.
