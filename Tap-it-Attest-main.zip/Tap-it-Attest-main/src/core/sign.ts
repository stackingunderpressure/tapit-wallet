/**
 * Sign and verify attestation envelopes.
 *
 * Signing appends an `AttestationSignature` over `attestationDigest`.
 * Multiple signers each sign the SAME digest -- that is how a
 * co-signed (notable / high-stakes) attestation and a multi-witness
 * declaration both work, exactly like DynastyTrust's death
 * declaration where N witnesses sign one shared target hash.
 *
 * BIP340 Schnorr over secp256k1, via `@noble/curves` -- the same
 * library and curve DynastyTrust signs PSBTs with. No Ed25519.
 */

import { schnorr } from '@noble/curves/secp256k1';
import { fromHex, toHex } from '../internal/hex.js';
import {
  attestationDigest,
  type AttestationEnvelope,
  type AttestationSignature,
} from './envelope.js';
import { isPublicKey, isSignature, publicKeyFromPrivate } from './keys.js';

export interface SignOptions {
  /** Optional named role recorded on the signature. */
  readonly role?: string;
  /** ISO timestamp; defaults to now. */
  readonly signedAt?: string;
}

/**
 * Sign an envelope and return a NEW envelope with the signature
 * appended. Envelopes are treated as immutable; the input is not
 * mutated. Re-signing with a key that already signed is rejected.
 */
export function signEnvelope(
  env: AttestationEnvelope,
  privateKey: string | Uint8Array,
  opts: SignOptions = {},
): AttestationEnvelope {
  const priv = typeof privateKey === 'string' ? fromHex(privateKey) : privateKey;
  const signer = publicKeyFromPrivate(priv);
  if (env.signatures.some((s) => s.signer === signer)) {
    throw new Error('this key has already signed the envelope');
  }
  const digest = attestationDigest(env);
  const sig = schnorr.sign(digest, priv);
  const signature: AttestationSignature = {
    signer,
    sig: toHex(sig),
    signedAt: opts.signedAt ?? new Date().toISOString(),
    ...(opts.role ? { role: opts.role } : {}),
  };
  return { ...env, signatures: [...env.signatures, signature] };
}

/** Verify one signature against an envelope's digest. */
export function verifySignature(
  env: AttestationEnvelope,
  signature: AttestationSignature,
): boolean {
  try {
    if (!isPublicKey(signature.signer) || !isSignature(signature.sig)) {
      return false;
    }
    const digest = attestationDigest(env);
    return schnorr.verify(fromHex(signature.sig), digest, fromHex(signature.signer));
  } catch {
    return false;
  }
}

export interface VerifyResult {
  /** True when at least one signature on the envelope verifies. */
  readonly valid: boolean;
  /** Distinct signers with at least one valid signature. */
  readonly validSigners: readonly string[];
  /**
   * Distinct signers whose signature did not verify and who have no
   * valid signature on the envelope. Reported so a caller can warn,
   * but they do NOT make the envelope invalid: a relayed envelope
   * with a bad signature appended must not poison a genuine one.
   */
  readonly invalidSigners: readonly string[];
}

/**
 * Verify every signature on an envelope.
 *
 * Validity is quorum-of-good: the envelope is valid if at least one
 * signature verifies, and invalid signatures are ignored rather than
 * poisoning the result -- anyone relaying an envelope can append a
 * junk signature, and that must not invalidate a genuine attestation.
 * Signers are de-duplicated, so a duplicated signature row cannot
 * fake a second signer.
 *
 * Returns only WHO signed validly. Signer weight is intentionally not
 * produced here -- it is not covered by the signed digest and so
 * cannot be trusted off the envelope. Derive weight with
 * `computeWeight` from a `WeightTable`, then feed that to
 * `evaluateTier`.
 */
export function verifyEnvelope(env: AttestationEnvelope): VerifyResult {
  const valid = new Set<string>();
  const invalid = new Set<string>();

  for (const sig of env.signatures) {
    if (verifySignature(env, sig)) {
      valid.add(sig.signer);
    } else {
      invalid.add(sig.signer);
    }
  }
  // A signer with any valid signature is valid; drop their bad rows.
  for (const signer of valid) invalid.delete(signer);

  return {
    valid: valid.size > 0,
    validSigners: [...valid],
    invalidSigners: [...invalid],
  };
}
