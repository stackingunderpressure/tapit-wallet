# DATA_MODEL.md — wallet data model spec

Companion to `DESIGN.md`. This doc formalizes every entity the
**wallet** needs that the `tapit-attest` library does not already
provide. Library types (`AttestationEnvelope`, `AttestationSignature`,
`Anchor`, `FieldNode`, `AttestationKind`, `TierName`, `WeightTable`,
`StoredAttestation`, `RecoveryRequest`, `RecoveryResponse`) are
reused as-is and never redefined here.

All design decisions referenced as `Dn` are in `DESIGN.md`. Open
questions referenced as `Qn` are at the bottom of `DESIGN.md` (plus
new ones surfaced here in §10).

## 1. Scope and conventions

### In scope
- Wallet-local state (keystore, contacts, groups the wallet has
  joined, inbox, weighting policy, custody bindings).
- Wire entities the wallet originates or receives that are NOT
  themselves library envelopes (candidacies, objections, tree
  amendments, relay pointers, recovery handshakes, group founding
  events). Many of these will be *carried by* library envelopes,
  but their payload schemas live here.

### Out of scope
- Library cryptographic primitives (already defined).
- The wallet's view-layer state (route, selected filter, modal
  stack). UX state is not data.
- Backend/relay server schema. The wallet's view of a relay is
  modeled (`RelaySubscription`); the relay's internal storage is
  the relay implementation's concern.

### Conventions
- **IDs** are content hashes (hex, sha256 unless specified otherwise)
  derived from canonical-JSON of the entity payload. Two wallets
  computing the same content produce the same ID.
- **Timestamps** are ISO-8601 UTC strings (`"2026-05-21T17:42:00Z"`),
  same as the library.
- **Public keys** are x-only secp256k1, 64 hex chars
  (same convention as `AttestationSignature.signer`).
- **Signatures** are BIP340 Schnorr, 128 hex chars.
- **Hashes** are 32-byte sha256 outputs, 64 hex chars, unless a
  tagged-hash variant is specified.
- TypeScript-flavored signatures are illustrative, not normative —
  the actual TypeScript will be derived from this spec.
- All entities are **immutable** once produced. Wallet state is
  built from append-only event logs + derived views.

---

## 2. Identity entities

### 2.1 `WalletIdentity`
The wallet's master state. Exactly one per wallet install.

```ts
interface WalletIdentity {
  // BIP39-style seed mnemonic, derived to a 64-byte master seed.
  // Stored only encrypted at rest; held in memory only while unlocked.
  readonly masterSeedRef: KeystoreRef;

  // Stable public identifier for this wallet, derived from
  // m/44'/0'/0' (or equivalent leaf at the "wallet identity" slot).
  // Used as the default signer for envelopes the user originates.
  readonly identityPubkey: string;

  // ISO-8601 of wallet creation.
  readonly createdAt: string;

  // User-chosen display name. Local only; never published.
  readonly displayName: string;
}

// Opaque reference into the platform keystore (OS keychain on
// desktop; IndexedDB + WebCrypto on PWA). Never serialized off-device.
type KeystoreRef = { backend: 'os-keychain' | 'webcrypto'; handle: string };
```

### 2.2 `LeafKey`
A derived keypair. The wallet holds many — one for wallet identity,
one per group membership, one per custodial child key, etc.

```ts
interface LeafKey {
  readonly pubkey: string;                 // x-only secp256k1
  readonly derivation: DerivationPath;     // how to re-derive from seed
  readonly purpose: LeafPurpose;           // why this key exists
  readonly createdAt: string;
  readonly rotatedFromPubkey?: string;     // prior key if this is a rotation
}

type DerivationPath = {
  readonly kind: 'deterministic';          // per D23
  readonly path: string;                   // e.g., "m/86'/0'/<group>'/<slot>'"
} | {
  readonly kind: 'imported';               // legacy or hardware-imported
  readonly source: string;                 // free-text provenance note
};

type LeafPurpose =
  | { type: 'wallet-identity' }
  | { type: 'group-member'; groupId: string; memberSlot: number }
  | { type: 'custody-child'; childId: string }
  | { type: 'recovery-peer'; peerId: string };
```

Per **D23**, `group-member` keys are deterministic from
`hash(group_internal_key)` and `member_slot`. The `member_slot`
bumps on rotation (per Q17's leading answer); a wallet restored
from seed alone re-derives every `LeafKey` by replaying the group's
amendment log to learn its current slot.

### 2.3 `Contact`
A counterparty record. One per pubkey the wallet has interacted
with or explicitly added.

```ts
interface Contact {
  readonly pubkey: string;
  readonly nickname: string;               // local label
  readonly category: string;               // free-text per D26
  readonly weightOverride: number | null;  // direct override; null = use category
  readonly firstSeen: string;
  readonly lastInteraction: string;
  readonly notes: string;                  // user free-text
  // Optional: groups this contact is a member of (denormalized cache).
  readonly knownMemberships: readonly { groupId: string; observedAt: string }[];
}
```

`category` is a wallet-local string. The default seed list per D26
is `family | household | close-friend | parish | civic-org |
acquaintance | stranger`, but users can add/rename freely.

### 2.4 `Peer`
A peer wallet that has agreed to act as a recovery responder for
this wallet (per D6). Distinct from `Contact` because the binding
is mutual and cryptographic.

```ts
interface Peer {
  readonly peerId: string;                 // content hash of the binding
  readonly peerPubkey: string;
  readonly nickname: string;               // local label
  readonly establishedAt: string;          // signed pairing timestamp
  // Library types from src/core/recovery.ts.
  readonly pairing: RecoveryPairing;       // signed mutual handshake
  readonly status: 'active' | 'revoked';
}

// RecoveryPairing carries the signed exchange that registered this
// peer; reuses RecoveryRequest/RecoveryResponse from the library.
interface RecoveryPairing {
  readonly request: RecoveryRequest;
  readonly response: RecoveryResponse;
}
```

Peers are the responders consulted during sync-recovery
(`src/core/recovery.ts`).

---

## 3. Group entities

Per **D14**, a group's identity is a Schnorr internal key plus a
script tree of members. The wallet must model both the static
identity and the evolving membership.

### 3.1 `Group`
The wallet's record of a group it has joined or is tracking.

```ts
interface Group {
  // Stable for the life of the group (D14). Content-hash of the
  // founding event for ID uniqueness; the internal pubkey itself
  // is also stable but a hash is cheaper to index.
  readonly groupId: string;
  readonly internalPubkey: string;         // x-only, never changes

  // Pointer to the latest amendment we've verified for this group.
  // Together with the amendment log this gives "the current tree".
  readonly currentTreeAmendmentId: string;

  // Pointer to the latest charter version we've verified.
  readonly currentCharterId: string;

  // Where this group's events live (D20).
  readonly durability: Durability;

  // Local user metadata.
  readonly nickname: string;
  readonly joinedAt: string;               // when *this wallet* joined
  readonly myLeafKeyPubkey: string | null; // null if tracking only, not member

  // Optional: signed pointer the wallet uses to subscribe to the
  // group's relay feed (D8).
  readonly relayPointer: RelayPointer | null;
}
```

### 3.2 `Charter`
A versioned, free-text governance document (D13). The current
charter is the latest in a signed amendment chain.

```ts
interface Charter {
  readonly charterId: string;              // content hash
  readonly groupId: string;
  readonly version: number;                // monotonic; 1 = founding
  readonly previousCharterId: string | null;  // null at v1
  readonly text: string;                   // free-text body
  readonly adoptedAt: string;
  // The envelope (library type) that carries this charter; signed
  // per the tree's quorum rule at adoption time.
  readonly envelopeId: string;
}
```

Per **D22**, charter evolves independently of the tree. The narrow
exception (a charter amendment that materially changes governance
authority) still produces a `Charter` but its adoption is gated by
the current quorum signing the amendment envelope.

### 3.3 `TreeAmendment`
One entry in the group's append-only tree-amendment log (D17). The
log is *the* source of truth for membership; the wallet's `Group`
record stores only a pointer to the latest entry.

```ts
interface TreeAmendment {
  readonly amendmentId: string;            // content hash
  readonly groupId: string;
  readonly version: number;                // monotonic; 1 = founding tree
  readonly previousAmendmentId: string | null;
  readonly newTreeRoot: string;            // Merkle root of the new tree
  readonly newThreshold: number;           // k in k-of-n
  readonly memberLeaves: readonly MemberLeaf[];   // full leaf set (small groups; see §3.4)
  readonly reason: TreeAmendmentReason;
  readonly adoptedAt: string;
  // The library envelope carrying this amendment, signed per the
  // PRIOR tree's quorum rule (this is what makes the chain valid).
  readonly envelopeId: string;
}

type TreeAmendmentReason =
  | { type: 'founding' }
  | { type: 'admission'; candidacyId: string }                // per D19
  | { type: 'removal'; targetPubkey: string }
  | { type: 'rotation'; targetPubkey: string; newPubkey: string }
  | { type: 'threshold-change'; from: number; to: number }
  | { type: 'tree-replacement'; note: string };               // arbitrary refactor

interface MemberLeaf {
  readonly memberPubkey: string;           // the leaf key
  readonly contactRef?: string;            // optional local nickname pointer
  readonly addedAt: string;
}
```

For groups large enough that publishing the full leaf list is
costly or privacy-sensitive, the amendment carries the Merkle root
only and members fetch sibling paths on demand. See §3.4.

### 3.4 `MembershipProof`
Cached proof that a given pubkey is a leaf in a given tree
revision. Computed locally and verified by the recipient; not
itself published.

```ts
interface MembershipProof {
  readonly groupId: string;
  readonly amendmentId: string;            // which tree revision this proves against
  readonly memberPubkey: string;
  readonly leafIndex: number;
  readonly siblingHashes: readonly string[];  // Merkle path
  readonly verifiedAt: string;
}
```

A `MembershipProof` is logarithmic-size (per D14) and can be
exchanged out-of-band when proving membership without disclosing
the full roster.

### 3.5 `Candidacy`
Per **D19**, an applicant publishes a candidacy event to start the
silent-objection window.

```ts
interface Candidacy {
  readonly candidacyId: string;
  readonly groupId: string;
  readonly applicantPubkey: string;        // the would-be member's leaf-to-be
  readonly sponsorPubkey: string | null;   // optional existing member
  readonly applicantSignedAt: string;
  readonly windowOpenedAt: string;         // when the relay accepted it
  readonly windowClosesAt: string;         // = opened + charter window length
  readonly status: CandidacyStatus;
  readonly envelopeId: string;             // library envelope carrying the candidacy
}

type CandidacyStatus =
  | { kind: 'open' }
  | { kind: 'objected'; firstObjectionId: string }
  | { kind: 'admitted'; admissionAmendmentId: string }
  | { kind: 'withdrawn' };
```

### 3.6 `Objection`
A signed objection event filed against an open candidacy.

```ts
interface Objection {
  readonly objectionId: string;
  readonly groupId: string;
  readonly candidacyId: string;
  readonly objectorPubkey: string;         // must be a current member at filing time
  readonly reason: string;                 // free-text, optional in UI
  readonly filedAt: string;
  readonly envelopeId: string;
}
```

Per Q16: whether one objection blocks (default) or whether a
threshold of objections is required is a charter parameter, to be
tightened.

### 3.7 `RelayPointer`
Per **D8**, a signed pointer to a relay where a group's events can
be found.

```ts
interface RelayPointer {
  readonly pointerId: string;
  readonly groupId: string;
  readonly relayUrl: string;               // wss:// or https://
  readonly issuedAt: string;
  readonly expiresAt: string | null;
  // Signed by the group (quorum-signed), so anyone trusting the
  // group's internal key can trust the pointer.
  readonly envelopeId: string;
}
```

A group can have multiple active pointers (multi-relay
replication; D20). The wallet stores all known pointers and
subscribes per its own policy.

---

## 4. Custody entities

Per **D1**, a wallet can hold child keypairs in trust (e.g., a
parent for a minor). Family-mode is the headline case;
generalizable to any custodial relationship.

### 4.1 `Custody`
A binding between the wallet's custodian role and a child key.

```ts
interface Custody {
  readonly custodyId: string;
  readonly childPubkey: string;            // the held key
  readonly childDisplayName: string;       // local label, e.g., "Sam (age 8)"
  readonly establishedAt: string;
  readonly expectedHandoff: string | null; // ISO date the child reaches majority
  readonly visibility: CustodyVisibility;
  readonly status: 'active' | 'handed-off' | 'revoked';
}

interface CustodyVisibility {
  // Per D1 + the "no surprise dossier" requirement: the child's
  // wallet should be able to see what's in their record before
  // accepting handoff. These flags govern what the child sees on
  // request, even before handoff.
  readonly childCanList: boolean;          // see envelope IDs / subjects
  readonly childCanRead: boolean;          // see full envelope content
  readonly childCanRedactRequest: boolean; // request removal before handoff
}
```

### 4.2 `CustodyHandoff`
The transition event when a child takes over their own keys.

```ts
interface CustodyHandoff {
  readonly handoffId: string;
  readonly custodyId: string;
  readonly initiatedAt: string;
  readonly completedAt: string | null;
  // The child generates their own master key; the custodian signs
  // an attestation transferring control. Both signatures land here.
  readonly custodianAcknowledgment: string;  // envelopeId
  readonly childAcceptance: string;          // envelopeId
}
```

---

## 5. Trust / weighting entities

Per **D26**/**D27**, the wallet ships opinionated category defaults
and a 1-hop transitive trust model with a 0.5 multiplier. This
section formalizes the policy.

### 5.1 `WeightPolicy`
The wallet's full trust policy. One per wallet (the user's own).

```ts
interface WeightPolicy {
  readonly directCategories: ReadonlyMap<string, number>;
  // Default seed per D26:
  //   family:1.0, household:1.0, close-friend:0.8,
  //   parish:0.5, civic-org:0.5, acquaintance:0.3, stranger:0.0

  readonly hopLimit: number;               // default 1 per D27; 0 disables transitivity
  readonly perHopMultiplier: number;       // default 0.5 per D27

  readonly perEdgeOverrides: readonly EdgeOverride[];

  readonly updatedAt: string;
}

interface EdgeOverride {
  readonly fromPubkey: string;
  readonly toPubkey: string;
  readonly weight: number;                 // overrides category
  readonly propagationCap: number | null;  // overrides hopLimit for this edge
}
```

`WeightPolicy` is the wallet's *config*. To pass weight values into
the library, the wallet materializes a concrete `WeightTable`
(`ReadonlyMap<pubkey, weight>`) at evaluation time by:
1. Walking the user's known contacts, mapping each to its
   `category` weight (or `weightOverride`).
2. Expanding 1-hop transitive trust via known group memberships:
   if Alice's friend Bob is in group G, and G has member Carol,
   Carol gets `bob_weight * perHopMultiplier`.
3. Applying any matching `EdgeOverride`.
4. Final stranger pubkeys (not categorized anywhere) — see §10
   open question.

### 5.2 `Category`
Categories are first-class for UX but plain strings on the wire.
The wallet maintains the user's category list with display metadata.

```ts
interface Category {
  readonly name: string;                   // the string used in Contact.category
  readonly displayLabel: string;
  readonly defaultWeight: number;          // mirrors WeightPolicy.directCategories
  readonly icon?: string;                  // optional UI hint
}
```

---

## 6. Inbox / activity entities

Per **D11**, the wallet's primary surface is a unified
reverse-chronological feed. Every item the wallet considers part of
that feed is an `InboxItem`.

### 6.1 `InboxItem`
A discriminated union over all surfaces.

```ts
type InboxItem =
  | IncomingEnvelopeItem
  | OutgoingEnvelopeItem
  | DraftItem
  | CandidacyItem
  | ObjectionItem
  | TreeAmendmentItem
  | CharterAmendmentItem
  | AnchorConfirmationItem
  | RecoveryRequestItem
  | RecoveryResponseItem
  | CustodyHandoffItem;

interface InboxItemBase {
  readonly itemId: string;                 // wallet-local UUID
  // Local arrival/receipt time -- when this item entered MY inbox.
  // Distinct from the signer's claimed `issuedAt` on incoming
  // envelopes; we order on what the wallet observed, not on what
  // the counterparty claims, so a late-arriving old envelope does
  // not bury itself in old history.
  readonly occurredAt: string;
  readonly tags: readonly Tag[];           // derived metadata (§6.2)
  readonly read: boolean;
  readonly actionRequired: boolean;        // user must do something
}

interface IncomingEnvelopeItem extends InboxItemBase {
  readonly type: 'envelope-in';
  readonly envelopeId: string;
  readonly subject: string;
  readonly kind: AttestationKind;
  readonly tier: TierName;
  readonly fromPubkeys: readonly string[]; // signers
}

interface OutgoingEnvelopeItem extends InboxItemBase {
  readonly type: 'envelope-out';
  readonly envelopeId: string;
  readonly subject: string;
  readonly kind: AttestationKind;
  readonly tier: TierName;
  readonly toPubkeys: readonly string[];   // intended recipients
  readonly deliveryStatus: 'pending' | 'delivered' | 'failed';
}

interface DraftItem extends InboxItemBase {
  readonly type: 'draft';
  readonly draftId: string;
  readonly subject: string;
  readonly kind: AttestationKind;
  readonly waitingFor: 'self-sign' | 'counterparty-sign';
  readonly counterpartyPubkey: string | null;
}

interface CandidacyItem extends InboxItemBase {
  readonly type: 'candidacy';
  readonly candidacyId: string;
  readonly groupId: string;
  readonly applicantPubkey: string;
  readonly windowClosesAt: string;
  readonly canObject: boolean;             // true if I'm a current member
}

interface ObjectionItem extends InboxItemBase {
  readonly type: 'objection';
  readonly objectionId: string;
  readonly candidacyId: string;
  readonly groupId: string;
}

interface TreeAmendmentItem extends InboxItemBase {
  readonly type: 'tree-amendment';
  readonly amendmentId: string;
  readonly groupId: string;
  readonly reason: TreeAmendmentReason['type'];
}

interface CharterAmendmentItem extends InboxItemBase {
  readonly type: 'charter-amendment';
  readonly charterId: string;
  readonly groupId: string;
  readonly version: number;
}

interface AnchorConfirmationItem extends InboxItemBase {
  readonly type: 'anchor-confirmed';
  readonly envelopeId: string;
  readonly bitcoinHeight: number;
}

interface RecoveryRequestItem extends InboxItemBase {
  readonly type: 'recovery-request';
  readonly fromPeerId: string;             // a peer asking ME to respond
  readonly requestId: string;
}

interface RecoveryResponseItem extends InboxItemBase {
  readonly type: 'recovery-response';
  readonly toPeerId: string;
  readonly responseId: string;
}

interface CustodyHandoffItem extends InboxItemBase {
  readonly type: 'custody-handoff';
  readonly handoffId: string;
  readonly childPubkey: string;
  readonly phase: 'initiated' | 'awaiting-acceptance' | 'completed';
}
```

### 6.2 `Tag`
Filter facets derived from item content. Not stored on the wire;
recomputed when items are indexed.

```ts
type Tag =
  | { type: 'subject'; value: string }
  | { type: 'kind'; value: AttestationKind }
  | { type: 'tier'; value: TierName }
  | { type: 'contact'; pubkey: string }
  | { type: 'group'; groupId: string }
  | { type: 'domain'; value: string }       // life-domain heuristic (work/family/civic/...)
  | { type: 'state'; value: 'unread' | 'action-required' | 'awaiting-counterparty' };
```

The `domain` tag uses a heuristic mapping from `kind` + payload
fields (e.g., kind=`agreement` + parties includes a known
employer-categorized contact ⇒ `domain: work`). User can override.

---

## 7. Storage / sync

### 7.1 `Durability`
Per **D20**, every persistable thing (group amendment log, charter,
roster cache, the wallet's own envelopes, etc.) picks from a menu
of durability strategies. Same shape for individual wallets and
groups.

```ts
interface Durability {
  readonly local: boolean;                 // always true in practice
  readonly anchorOpentimestamps: boolean;
  readonly relays: readonly RelaySubscription[];
  readonly managed: ManagedStorageBinding | null;
}

interface ManagedStorageBinding {
  readonly provider: 'supabase' | string;
  readonly endpoint: string;
  readonly accountRef: string;             // wallet-local keystore ref
  readonly tier: 'free' | 'paid';
}
```

### 7.2 `RelaySubscription`
The wallet's binding to a specific relay. May be subscribed for
its own envelopes, for a specific group, or both.

```ts
interface RelaySubscription {
  readonly subscriptionId: string;
  readonly relayUrl: string;
  readonly subscribedAt: string;
  readonly purpose: RelayPurpose;
  readonly status: 'connected' | 'disconnected' | 'errored';
  readonly lastSeenAt: string;
}

type RelayPurpose =
  | { type: 'personal' }                   // my own outgoing/incoming
  | { type: 'group'; groupId: string }
  | { type: 'discovery' };                 // pulling RelayPointers for tracked groups
```

### 7.3 `LocalStore`
The wallet's local persistent store, implementing the library's
`AttestationStore` interface so the existing sync/recovery code
works without modification. Wallet-extension entities (groups,
contacts, etc.) live in separate keyed tables alongside.

```ts
interface LocalStore extends AttestationStore {
  // The library-required surface (put/get/list) is inherited.

  // Wallet-extension tables. Each one is a keyed dictionary
  // persisted to IndexedDB (PWA) or SQLite (desktop).
  readonly contacts: KeyedStore<string, Contact>;        // by pubkey
  readonly peers: KeyedStore<string, Peer>;              // by peerId
  readonly groups: KeyedStore<string, Group>;            // by groupId
  readonly charters: KeyedStore<string, Charter>;        // by charterId
  readonly amendments: KeyedStore<string, TreeAmendment>; // by amendmentId
  readonly candidacies: KeyedStore<string, Candidacy>;
  readonly objections: KeyedStore<string, Objection>;
  readonly relayPointers: KeyedStore<string, RelayPointer>;
  readonly custodies: KeyedStore<string, Custody>;
  readonly inbox: AppendOnlyLog<InboxItem>;              // by occurredAt
  readonly weightPolicy: SingletonStore<WeightPolicy>;
  readonly identity: SingletonStore<WalletIdentity>;
}
```

`KeyedStore`, `AppendOnlyLog`, `SingletonStore` are simple
abstractions over the underlying persistence (IndexedDB / SQLite);
their concrete shape is an implementation detail, not part of the
data model.

---

## 8. Indexing strategy

The inbox (D11) is only legible at scale if filtering is fast.
Indexes the wallet maintains on top of the stored entities:

- **By subject**: `Map<subject, InboxItemId[]>` — primary "all
  envelopes about Sam" view.
- **By contact**: `Map<pubkey, InboxItemId[]>` — primary "all
  interactions with Alice" view.
- **By group**: `Map<groupId, InboxItemId[]>` — "all activity in
  the parish".
- **By kind**: `Map<AttestationKind, InboxItemId[]>` — "show me
  every agreement".
- **By tier**: `Map<TierName, InboxItemId[]>` — "high-stakes only".
- **By tag**: `Map<TagKey, InboxItemId[]>` — arbitrary facet.
- **By state**: explicit `actionRequired` and `read` columns on
  inbox rows.
- **Action-items queue**: derived view of all
  `actionRequired === true` items, ordered by deadline-then-recency.

Indexes are **derived**; the source of truth is the entity tables.
Index rebuild from scratch should be fast enough to run on app
startup if the index is stale or missing.

---

## 9. Cross-references and invariants

These are properties the wallet must enforce when accepting or
producing entities. Violations should fail loudly, not silently.

- A `Candidacy.groupId` must reference a known `Group`.
- An `Objection.objectorPubkey` must be a `MemberLeaf` of the
  current `TreeAmendment` of `Objection.groupId` *at the time the
  objection was filed*. (Late-filed objections by then-current
  members remain valid even if the objector is later removed.)
- A `TreeAmendment` is valid only if its carrying envelope's
  signature satisfies the **previous** amendment's quorum rule
  (D14 / D17). The wallet's verifier walks the amendment chain
  from founding forward; any link that fails this rule poisons
  the rest of the chain.
- A `Charter` of version > 1 must have a `previousCharterId` that
  resolves to a known `Charter`. Same rule about governance-
  affecting amendments needing quorum sig per D22.
- `Group.currentTreeAmendmentId` and `Group.currentCharterId` must
  always point to the highest-version verified entries.
- A `Custody.childPubkey` must NOT equal `WalletIdentity.identityPubkey`
  (a wallet cannot custody itself).
- A `LeafKey` with purpose `group-member` must have a derivation
  path matching `m/86'/0'/hash(group_internal_key)/member_slot`
  (or be marked `imported`).
- For every `InboxItem`, at least one referenced entity must exist
  in the local store (no dangling references).

---

## 10. Open questions surfaced

New questions that appeared while drafting this model. Add to
`DESIGN.md`'s open questions list at next sweep.

### Q18. Stranger fallback weight: library vs wallet
`tapit-attest`'s `computeWeight` (`src/core/weighting.ts:42`)
defaults unknown signers to **1**. **D26** sets the wallet's
`stranger` category at **0.0**. The wallet's materialized
`WeightTable` (§5.1 step 4) needs a defined behavior for pubkeys
not in any contact, group, or override.

Options (carried forward from HANDOFF.md):
1. Wallet always populates the table for every signer it has ever
   seen (explicitly or as a "stranger" entry), so the library
   fallback is never reached.
2. Library `computeWeight` gains an `unknownDefault: number`
   parameter; wallet passes `0`. **Lean.**
3. Library default flips to 0. Riskier for non-wallet integrators.

### Q19. Large-group membership: full leaf list vs root-only
`TreeAmendment.memberLeaves` carries the full leaf set in §3.3.
That's fine for parish-scale groups (tens to hundreds) but breaks
down for civic-scale (thousands+). Need a threshold above which
the amendment publishes only the root + a means for members to
fetch sibling paths on demand (the relay would host an
authenticated leaf-index). Decide threshold and the on-demand
protocol.

### Q20. Inbox item lifecycle: when does an item leave the inbox?
The inbox is "everything", but a 10-year-old envelope shouldn't
crowd today's view. Archive policy: time-based (auto-archive after
N months), interaction-based (archive once no `actionRequired` and
read), or never (always show all, rely on filters)? Lean: never
auto-archive; rely on filters and a "recent" default view.

### Q21. Custody handoff: identity continuity claim
When a child takes their own keys at handoff (§4.2), do the
attestations made *about* them while under custody carry over by
default? Crypto-wise yes — they're already in the wallet's store
keyed by the child's pubkey — but the child may want to start
fresh. Need explicit handoff UX for "carry over everything" vs
"transfer only what I choose."

---

## Appendix: derivation summary

Decisions in `DESIGN.md` mapped to entities in this doc.

| Decision | Entity / section |
|---|---|
| D1 custodian relationship | `Custody`, `CustodyHandoff` (§4) |
| D6 no-coercion | `Durability` (§7.1) |
| D8 signed relay pointers | `RelayPointer` (§3.7), `RelaySubscription` (§7.2) |
| D11 unified inbox | `InboxItem` (§6) |
| D13 free-text charter | `Charter` (§3.2) |
| D14 taproot key tree | `Group.internalPubkey`, `TreeAmendment` (§3) |
| D17 append-only amendment log | `TreeAmendment` chain (§3.3) |
| D18 single-founder bootstrap | `TreeAmendmentReason.founding` (§3.3) |
| D19 silent-objection admission | `Candidacy`, `Objection` (§3.5–3.6) |
| D20 group durability menu | `Durability` (§7.1) |
| D21 fork on lost quorum | (no entity; the founding event of the fork is a normal `Group`) |
| D22 charter ↔ tree decoupled | `Charter.adoptedAt` independent of `TreeAmendment` chain (§3) |
| D23 deterministic leaf-key derivation | `DerivationPath.kind === 'deterministic'` (§2.2) |
| D24 context-aware tap | (state machine, not an entity; flow doc) |
| D25 tap-to-cosign | (state machine, not an entity; flow doc) |
| D26 mycelium category defaults | `WeightPolicy.directCategories` (§5.1) |
| D27 1-hop transitive trust | `WeightPolicy.hopLimit`, `perHopMultiplier` (§5.1) |
