# Tapit Mycelium — Design Doc

A wallet-first deployment of the `tapit-attest` primitive, organized as a
mycelial trust network that grows from key clusters outward.

**Status:** v0 design sketch. Living doc — captures decisions made and
questions still open. Updated as the design conversation continues. Nothing
here has been built yet beyond the underlying primitive in `src/`.

---

## The vision

The system has **no built-in roles**. There is no "family kind", no
"town kind", no "doctor kind". There are only **keys**, the
**attestations they sign**, and the **relationships those attestations
describe**. A *family* is a cluster of keys that have decided to be a
group; a *BBQ club*, a *river party*, a *parish*, a *town board* are the
same primitive. What distinguishes them is the density, age, and content
of the attestations between their keys, and how each verifier chooses to
weight them.

The smallest meaningful trust unit is **a group of keys that vouch for
each other**. A family is the most common form — parents who hold their
own keys, agree to be a unit, and act as custodians for their children's
keys until handoff. The same primitive scales up: a town is a cluster of
family clusters and individual keys; a county is a cluster of towns.
Each level is just signed events between keys.

The wallet is a **library of attestations** the user is keeping up with —
about themselves, about people they're custodians of, about groups they
belong to. The wallet's job is to hold those envelopes, organize them
into something humans can use, and produce new envelopes when the user
needs to attest to something.

There is no central authority. Protocol-compatible wallets — anyone
running the same envelope shape — are interoperable by construction.

The wallet runs **local-first** in both web (PWA) and desktop forms,
shipping in parallel from the same codebase. Encrypted backup to
Supabase is an opt-in convenience, not a trust dependency: Supabase only
ever sees ciphertext, and a wallet that never logs in is equally capable.

---

## What the primitive already gives us

`tapit-attest` (the library in `src/`) already covers most of the trust
math. We do not need to redesign the envelope, the digest, or the signing
model.

| Vision element                                | Primitive                                                                 |
|-----------------------------------------------|---------------------------------------------------------------------------|
| Multi-signer attestations                     | `core/envelope.ts` — multiple `signatures[]` per envelope                 |
| Every signer is "just a key"                  | One signing model: x-only secp256k1 + BIP340 Schnorr (`core/sign.ts`)     |
| Tier dials (routine / notable / high_stakes)  | `core/tiers.ts` — `requiredSigners`, `minSignerWeight`, `requireCoSign`   |
| Mycelium = whose weights you trust            | `WeightTable` lives outside the envelope (`core/weighting.ts`)            |
| Six attestation kinds                         | `identity`, `relationship`, `credential`, `prediction`, `agreement`, `meta` |
| Handoff from custodian to subject             | `createSuccessionLink` / `verifySuccessionChain` (`core/succession.ts`)   |
| Encrypted local + remote storage              | AES-256-GCM + PBKDF2 (`core/encryption.ts`); pluggable `AttestationStore` |
| Lost-wallet rebuild from peers                | `buildRecoveryRequest` / `Response` / `rebuildFromResponses`              |
| Bitcoin-backed timestamping                   | OpenTimestamps (`core/anchor.ts`, `anchor/opentimestamps-provider.ts`)    |
| Revocation state machine                      | `RevocationLedger` (`core/revocation.ts`)                                 |

Crucially: **weight is not in the envelope and can't be forged by a
relay**. The verifier picks the `WeightTable`. That is exactly how a
mycelium emerges — it is a choice each wallet makes, not a structure
baked into the protocol. Two wallets running the same library can trust
totally different mycelia and still verify each other's attestations.

The fact that OpenTimestamps anchoring is already in the primitive is
load-bearing for the no-roles model: "we've been a group for ten years"
is *provable* because the oldest mutual attestations between the keys
were Bitcoin-anchored at the time.

---

## Decisions taken (v0)

These are settled enough to design against. Open to revision if downstream
work uncovers a problem.

### D1. Child identity: hybrid escrow + reissue option

**Default:** the custodian wallet (most often a parent's family-mode
wallet) generates a real keypair for the child at birth and holds it
under escrow. The child accumulates signed history from day one — every
attestation about them is verifiable forever against a stable key.

**At majority** (or earlier, at custodian release), the grown child
chooses:

- **Keep the escrowed key.** Wallet seed is handed off; signed history
  flows seamlessly into the new wallet under the same identity.
- **Generate a fresh key.** New wallet creates a new keypair; the
  custodian signs a succession link binding it to the escrowed key.
  Verifiers walk the chain to see the unbroken history.

Both paths use `createSuccessionLink`. The second creates an explicit
chain; the first trivially continues without one.

**Why hybrid:** unbroken history matters (school records, medical
attestations, sports milestones shouldn't vanish at adulthood), but
sovereignty also matters (some people want to start clean on their own
terms). Hybrid serves both.

### D2. Group signing: group key + member keys

A group has its own keypair (a "group key"), and each member has their
own. They serve different purposes:

- **Group key** signs joint actions *as the group* (the family attests,
  the parish attests, the BBQ club attests). Internally requires member
  quorum per group policy — a single member cannot sign with the group
  key alone. Externally, verifiers see one signer (the group) with one
  identity.
- **Member keys** sign personal acts and group-internal endorsements.
  A parent endorsing a milestone uses their own key. A parent's own
  life attestations (degree, employment, friendships) use their own key.

This applies uniformly to family, BBQ club, parish, town board. Family
is the canonical example because most people will meet the primitive
through it; the mechanics are identical at every scale.

The existing envelope already supports multi-sig. The **new** piece is
**quorum coordination** for the group key — propose, collect member
sigs, produce the final group-key signature. `tapit-attest-quorum.zip`
at the repo root almost certainly drafts this; opening it is a natural
early step.

### D3. Storage: offline-first, optional hosted

Wallet works fully offline by default. Local encrypted store; no account
required; the wallet never phones home.

Hosted backup is opt-in:

- User can attach a Supabase account at any time.
- Backup is **ciphertext only.** The encryption key is derived from a
  passphrase (or device key) held by the user; Supabase cannot decrypt.
- Detaching from Supabase is one-click and breaks nothing. The local
  copy is always authoritative.

Result: sovereignty is the default, convenience is the upgrade, and the
user's data never lives unencrypted on someone else's server.

### D4. No roles — only keys and relationships

The system does not encode `kind: 'family' | 'town' | 'church'` anywhere
in the envelope. A "family" is whatever cluster of keys have been
mutually attesting to each other in family-like ways. A "town" is the
same primitive at a larger scale. The verifier walks the attestation
graph and decides what to call the cluster.

What this collapses:
- No "family kind" in the envelope. Existing `identity` / `relationship`
  / `meta` kinds cover everything.
- N3 (quorum module) becomes a **general group-key quorum** pattern,
  not a family-specific one. Same code serves a BBQ club's shared key,
  a parish's, a town board's.
- "Membership" is provable through dated, anchored mutual attestations,
  not through a centrally-issued roster. The roster is *derived* from
  the graph.

What this *doesn't* eliminate: groups still benefit from publishing
human-readable handles ("we collectively call ourselves the Winchester
family", "we are the Riverdale BBQ Crew"). Those are `meta`
attestations, not a new kind, and they're optional shortcuts for
presentation — the underlying graph is what's authoritative.

### D5. Form factor: parallel-ship web + desktop, one codebase

A single React/TS codebase is shipped as **both** a PWA (web) **and** a
downloadable desktop app (Tauri or Electron) from day one. Same UI,
same data layer, same envelopes. The web shell trades stronger key
isolation for zero-install reach; the desktop shell offers stricter
sandboxing and a more sovereign feel. Users can move between them by
exporting their store.

This closes the prior Q6 (form factor). The cost is more up-front
engineering than a staged release; the gain is one source of truth and
no "real version comes later" framing.

### D6. Birth attestation is two-stage

Two layers, separately signed:

1. **Family-issued birth attestation** — the family group key (with
   parent quorum) signs the primary "this child exists, born on this
   date, this is their key" attestation. Self-sufficient; works with no
   external infrastructure.
2. **External credential attestations** — hospital, registrar, midwife,
   etc. independently sign `credential` attestations that reference the
   birth attestation. They corroborate but do not replace it.

Verifiers see both. A WeightTable that values civic registration looks
for stage 2; a verifier that doesn't, doesn't. This keeps "who is this
person" cleanly separated from "who vouches for the circumstances", and
lets families bootstrap their kids' identities even when the local
hospital doesn't have an attesting wallet yet.

### D7. Envelopes are transport-agnostic; wallet is a library

Envelopes are self-contained signed objects. They can travel by NFC, QR,
email, file transfer, Bluetooth, sneakernet on a USB stick — the
envelope verifies the same way regardless of how it arrived. The wallet
is a **library** of those envelopes, indexed and organized so the user
can find what they need.

Implications:
- No required network protocol. A wallet that never connects is fully
  functional.
- "Tap" (NFC) is one transport among many, not the protocol's identity.
- Backup is the user's responsibility (with hosted backup as opt-in
  convenience per D3). Lose your library, recover from peers via the
  primitive's existing recovery flow.

### D8. Group hosting is Nostr-relay-style; relays are storage, not authority

Groups host their attestations on **relays** in the Nostr sense: any
server (run by the group, by a member, by a third party) that holds
signed events keyed to the group's pubkey. The relay's job is
discoverability and availability — *not* deciding what's true.

What lives on a relay:
- Public attestations the group has signed (rosters, public meta).
- Member-signed events that the group's admission policy has accepted.
- Optional encrypted events visible only to members (Nostr NIP-17
  style).

What governs the relay:
- The group's pubkey is the identity. The relay endpoint is a pointer
  signed by that key (`meta` attestation: "the Winchester family's
  current relay is at X"). Moving servers means publishing a new pointer.
- The relay's **admission policy** is a published, signed config event.
  Defaults envisioned: open-publish, librarian-only, two-member
  sponsorship, full quorum. Different groups pick different policies;
  the primitive does not impose one.
- Membership begins with a **founder manifest** — the founders publish a
  signed event naming themselves as the seed roster. Subsequent
  admissions go through the policy.
- Departures, expulsions, and disputes are themselves signed events.
  They don't unwrite history; they add new facts ("Bob's membership
  ended on 2030-04-08").

**Critical clarification (the pushback):** the relay is *availability
infrastructure*, not authority. A bad-faith relay can drop events; a
good-faith mirror can pick them up. What is authoritative is the
**signed event graph**, evaluated by the verifier against their
WeightTable. "On the relay" is evidence; signatures plus anchoring are
proof. "Two-member sponsorship" is not Sybil-proof on its own — it is a
UX gate; the verifier's weighting is what defends against collusion.

### D9. No AI agent in v1 (deferred to future direction)

Earlier framing put a premium AI agent tier in v1. **Reverted.** v1
ships with a single tier — a sovereign wallet with the inbox UX (D11),
group-tree governance (D14–D18), and mycelium recovery (D6). No agent,
no bot-to-bot negotiation.

The agent direction is preserved as a future possibility (see Future
Directions section). Constraints if/when it's added:

- The agent holds no signing key and signs nothing. Every signature on
  every envelope remains a human decision.
- The wallet exposes a clean interface that an agent can drive (read
  envelopes the user shares with it, propose drafts, surface library
  state). This interface should be designed openly enough that a user
  can plug in their own agent (Claude, ChatGPT, local model) — we don't
  need to ship the agent ourselves to make agents possible.
- Bot-to-bot negotiation between counterparty agents — and its
  guardrails — designed when the agent layer is real, not before.

### D10. Multi-key identity is shown as one with a timeline badge

When a person/entity is represented by multiple keys over time (escrow
→ adult key transition, deliberate rotation, recovered wallet), the
wallet displays them as **one continuous identity** with a visible
timeline badge marking each key transition. A one-click toggle reveals
the underlying separate keys when the user (or a verifier) wants to
inspect the seam. Merges are themselves attestations — auditable, not
hidden.

### D11. Library organization: unified inbox / timeline

The wallet's primary surface is a **reverse-chronological inbox** —
one unified feed of everything. Like email, but the universe of items
is broader than just received messages. Items in the feed:

- **Incoming envelopes** from others.
- **Outgoing envelopes** you signed and sent.
- **Drafts in flight** — awaiting your signature, awaiting the
  counterparty's signature.
- **System & group activity** — anchor maturity confirmations,
  recovery requests from peers, group-tree amendment events,
  charter amendments, admission candidacies (D19).

Everything is tagged and filterable; nothing is hidden in a separate
"activity" sub-app. Subject, life domain, issuer, tier, and item-type
surface as **chips/badges** on each row and as filterable facets. The
default view shows everything; users dial in via filters.

Implications:
- Subject and domain are derived metadata (auto-tagged from envelope
  `kind` + payload, with manual override).
- Action-items (drafts needing signature, candidacies you can object
  to before the window closes) carry prominent badges and rise to
  the top of attention.
- Search and filter are first-class — the inbox is only legible at
  scale if filtering is good.

(Confirm interpretation: "system & group activity in the inbox" was
read as "yes, even these belong in the unified feed". If incoming
envelopes were meant to live on a separate surface, this needs
revisiting.)

### D12. ~~AI agent is draft-only, never signs~~ — folded into D9

Constraint preserved for any future agent: no signing key, ever.
Decision deferred along with the agent itself.

### D13. Group admission is governed by a free-text charter

A group's admission rules live in a **free-text `meta` envelope** —
a "charter" — signed by the group's founders (and amended over time
by signed amendments). There is **no machine-readable policy schema**
(prior Q10 is closed). This matches how real bylaws work: human
language, interpreted in context.

Consequences:
- The relay (N8) cannot auto-accept member events purely by evaluating
  the charter. Acceptance requires **judgment** — by a human admin, by
  an agent (D9) acting on the admin's behalf, or by a delegated
  member-vetting quorum per the charter's own description.
- Each admission decision is itself a **signed event** by whoever has
  authority per the charter (e.g., the admitting members' keys plus the
  group key). Verifiers see a chain: charter → admitting signatures →
  new member's first event. This is the auditable trail.
- The cost: no purely deterministic verification of "is this group
  following its own rules". The agent layer (D9) is the natural place
  to assist humans in interpreting and following charters consistently.

### D14. Group identity = taproot-style key tree

A group's cryptographic identity is a **Schnorr internal key + a
Merkleized script tree** (taproot-style construction, borrowed from
Bitcoin's design but not on Bitcoin — no UTXOs, just the math). Each
**member is a leaf** of the tree. The current **quorum rule** (k-of-n
threshold) is a script path.

- The **internal key** is the group's stable, permanent identity. It
  never changes for the life of the group.
- The **script tree** encodes "who can sign for the group right now"
  and is fully replaceable.
- The current quorum can sign an **amendment event** that produces a
  new tree (add/remove/replace leaves, adjust threshold). As long as
  some valid quorum exists at the current state, governance is
  recursively amendable.
- A member proves inclusion by producing a **Merkle path** from their
  leaf to a known tree root — a logarithmic-size proof; the full
  roster need not be public.
- A signature "on behalf of the group" is a **script-path Schnorr
  signature** satisfying the current quorum rule. Verifiers check it
  against the group's tree active at sign-time (see D16).

This subsumes the vague "group keys" mentioned in D8.

### D15. Threshold signatures via FROST (k-of-n) and MuSig2 (n-of-n)

For multi-signer group signatures: use **FROST** for k-of-n threshold
quorums, **MuSig2** for n-of-n (full consensus). Both produce a single
aggregated Schnorr signature indistinguishable from a single-signer
signature, so:

- On-wire size is constant regardless of quorum size.
- Verifiers learn "the group signed" without learning *which subset*
  of members cooperated (signer privacy within the group).
- External verifiers verify exactly as they would a single-signer
  envelope.

### D16. Per-group derived keys; cross-group linkage is opt-in

A user's wallet holds a **master key**. Each group membership uses a
**per-group child key** derived deterministically from the master
(BIP32-style) under a group-specific derivation path. The group's tree
sees the child key as the leaf; observers across groups see
uncorrelated keys.

Cross-group correlation is opt-in: the user can publish a **signed
linkage envelope** stating "these N leaves across these N groups are
the same person", revealing the connection when (and only when) they
want to.

### D17. Tree history is an append-only signed log

Groups maintain a **forward-linked, append-only log of tree
amendments**. Each amendment event:

- References the **predecessor tree root** explicitly.
- Is signed under the **predecessor tree's quorum rule**.
- Specifies the new tree (leaves + threshold) in full.

A verifier seeing an old signature on an old envelope walks the log
from the current state back to the tree-version active at sign-time,
checks the chain of amendment signatures, and then verifies the
envelope signature against that historical tree. The log is hosted by
the group's relay (D8); members maintain enough local cache to verify
independently when their relay is unreachable.

### D18. Group founding: single-founder bootstrap is the default path

A new group starts as a **1-of-1 tree** with the founder as the only
leaf. The founder signs in subsequent members one at a time, each
addition published as an amendment event. The founder raises the
quorum threshold over time as the group matures. Multi-founder
ceremonies (a co-signed initial state with multiple leaves and an
already-elevated threshold) are also supported but not the default.

### D19. Group admission: silent-objection window

Admission to an existing group works by **silent objection**:

1. An applicant (or their sponsor) publishes a **candidacy event**
   signed by the applicant's key and naming the group. The event lands
   in the group's relay feed and in members' inboxes.
2. The candidacy enters a **waiting window** (length specified in the
   group's charter — e.g., 14 days).
3. During the window, **any current member** can publish a signed
   **objection event** referencing the candidacy.
4. When the window closes:
   - **Zero objections** → the candidacy is automatically promoted to
     an admission event. The current quorum signs an amendment that
     adds the applicant as a leaf in the group's tree (D14). The
     amendment lands in the append-only log (D17).
   - **Any objection** → admission is blocked. The charter describes
     what happens next (re-application cool-down, mediation, etc. —
     human governance, not protocol-level).

Quiet is the default. Silence is consent. Admission requires no
active administrative attention beyond watching for candidacies you
want to object to. This matches how informal communities actually let
people in.

Tightening still needed (Q16).

### D20. Group durability is a group choice, from the same menu as a person

The amendment log (D17), the charter, the relay subscription, the
roster cache — everything a group needs to persist — is hosted under
the same no-coercion menu individuals use for their own attestations
(D6 / N5):

- **Local-only** — every member caches; if every member's cache is
  lost, the history is gone. Acceptable for small groups that value
  ephemerality.
- **OpenTimestamps anchor** — cheap, public, proves *when* an
  amendment existed; doesn't store the content.
- **One or more relays** — durable, queryable, replication is the
  group's call (single relay, multi-relay mirror, hot-standby, etc.).
- **Paid managed storage** (e.g., a Supabase-backed store) — for
  groups that want a billable durability SLA without running a relay.

The group picks its mix; members can layer additional caching on top
for their own peace of mind. The protocol does not dictate. A group
that wants to be findable across decades will pay for / run durable
hosting. A group that wants to be ephemeral can stay local-only.

### D21. Lost-quorum failure mode: fork, don't recover

If enough members lose keys at once that the current tree's threshold
becomes unsatisfiable, the group is **cryptographically frozen** — no
recovery path, by design.

- **Old attestations stay valid forever.** Anyone holding an envelope
  the old group signed can still verify it against the old internal
  key. Past truth is unaffected.
- **The old group's tree can never be amended again.** No quorum can
  produce an amendment signature.
- **Remaining members fork.** They create a new group with a new
  internal key. The new group can publish a signed attestation
  declaring "we are the continuation of [old key]". This is just a
  normal attestation — no special primitive.
- **Continuity is a social claim, not a cryptographic one.**
  Outsiders verify the new key independently and decide via their
  mycelium weights (N4) whether to treat the new group as the
  successor. A bad actor can claim succession too; the social layer
  sees who actually endorsed them.
- **No one can fake it** because the new key was generated by
  someone who had to be authorized in the new tree's founder set,
  and the succession claim is signed and auditable.

This is the no-coercion principle (D6) extended to time: the
cryptography refuses to forge a signature on a group's behalf no
matter how badly we want it to, and the social/mycelium layer handles
continuity. Forking is not a failure mode — it's the legitimate
escape valve.

### D22. Charter and tree evolve independently

Charters (D13) change rarely. Trees (D14) change as membership
churns. Coupling them would force constant charter re-signing for
every routine member addition, with no benefit.

- Each lives on its own append-only log.
- An envelope or amendment references the **current charter version
  and current tree version** at the moment of signing.
- Verifying "did the group at time T follow its charter?" pulls the
  charter version current at T and the tree version current at T;
  cross-references are by hash.

Open subtlety: when a charter amendment *itself* materially affects
who the quorum is or what the quorum's authority is, the charter
amendment event arguably needs the existing quorum's signature
(treated as a tree-affecting event). The general principle stays
decoupled; charter changes that touch governance authority are the
narrow case that needs both.

### D23. Per-group leaf keys are deterministically derived from the master

A user's leaf key in any given group is derived from their master
wallet seed by a deterministic path — likely something shaped like:

```
m / purpose / hash(group_internal_key) / member_slot
```

Consequences:

- **Restore-from-seed recovers all group memberships** with no
  per-group backup. The wallet, once restored, can re-derive every
  leaf key it ever held, look up the corresponding groups, and
  rejoin the relay feeds.
- **No "lost a group membership" disaster** if the wallet device
  dies but the seed survives.
- Slight unlinkability cost vs. fully random per-group keys, but
  group memberships are already advertised on relays — the
  derivation isn't the privacy bottleneck.

Sub-decision needed (Q17): the **`member_slot`** semantics under
leaf-key rotation. When a compromised member's leaf is replaced in
the tree, do they bump the slot (so the new key is also
deterministic from the seed), do they store the new key explicitly,
or do we forbid in-place rotation and require leaving + rejoining the
group? Lean toward bump-slot — keeps the determinism property intact.

### D24. NFC tap is context-aware

The wallet maintains a **"staged for tap"** state at all times. When
two wallets touch:

- **First contact** (no record of the other's key) → exchange public
  keys + introduce. Both wallets add the other to contacts and ask
  the user to assign a category / weight (D26).
- **Draft staged for this counterparty** → transfer the draft.
  Counterparty's wallet surfaces it for review.
- **Finalized attestation staged for this counterparty** → deliver
  the attestation; counterparty's wallet imports it into the inbox.
- **Recovery flow active** → register the other wallet as a peer
  responder (D6).

Resolution rule when multiple are eligible: **highest specificity
wins** — an explicitly staged item beats the default introduction.
After every tap, both wallets show a clear "what happened" toast
("key added", "draft sent", "attestation received") — no silent
ambiguity.

### D25. Tap-to-cosign is a first-class flow

The headline NFC interaction: two humans, face-to-face, **co-sign one
envelope in a single tap** (or short sequence of taps).

Choreography:
1. One party drafts the envelope on their wallet ahead of time
   (subject, kind, payload).
2. Both wallets touch.
3. Both wallets surface the same draft. Each side reviews on their
   own screen. (Both sides see the same payload hash — wallets cross-
   check; mismatch aborts the flow with a clear error.)
4. Each side presses **Sign**. Signatures are exchanged at the radio
   layer.
5. The completed multi-signed envelope is stored in both wallets and
   pushed to whatever durability path the originator chose (D20-style
   menu).

Failure modes:
- **Tap interrupted mid-flow** → fall back to "sign on your own; send
  the partial envelope via another path."
- **Only one side signs** → envelope stays in drafts on both sides,
  flagged "awaiting counterparty signature."
- **Draft hash mismatch** → abort. Probably means one side edited
  after the other did; re-stage and retry.

This is the moment that makes the product feel like a wallet rather
than a database — the social act and the cryptographic act happen in
the same gesture.

### D26. Mycelium ships opinionated default weights

A fresh install starts with a populated `WeightTable` keyed by
category, not by identity:

```
direct:
  family:           1.0
  household:        1.0
  close-friend:     0.8
  parish:           0.5
  civic-org:        0.5
  acquaintance:     0.3
  stranger:         0.0
transitive:
  1-hop multiplier: 0.5   (per D27)
```

When the user adds a contact or subscribes to a group, the wallet
assigns the category default; the user can override per-relationship
at any time. All numbers are editable in settings.

Categories are **suggestions, not protocol** — they're shorthand for
populating the `WeightTable`. The library doesn't know what "family"
means; it sees only edges with weights. A user who hates categories
can scrap them and assign per-contact weights directly.

### D27. Transitive trust: 1 hop, discount 0.5, by default

Default propagation depth: **1 hop**. A friend-of-friend at direct
weight 1.0 propagates to me at 0.5. A friend-of-friend-of-friend
counts as 0.

Two adjustable knobs in settings:
- **Hop limit** (default 1; can go 0 = direct-only, 2+ = multi-hop
  cumulative).
- **Per-hop multiplier** (default 0.5; lower for stricter trust,
  higher for looser).

Per-edge overrides exist for the rare case ("don't let trust from
this friend propagate further"; "extend trust from this group two
hops"), but defaults handle most users.

Why 1 hop as default: meaningful network effect (friend-of-friend is
the canonical mycelium case), bounded graph (no combinatorial
explosion), simple mental model.

---

## What's new (not in the primitive)

The library is the trust math; these are the pieces that need to be
built on top.

### N1. Wallet app
Local keystore, signing UX, attestation viewer, library browser, NFC/QR
interactions. Same codebase ships as PWA and desktop (D5).

### N2. Custodian mode
A wallet acting as custodian for one or more child keypairs (per D1).
Distinct UI for "your keys" vs "keys you hold in trust." Handoff flow at
majority. Visibility controls so a kid can't be surprised by what's in
their dossier when they get it. Folded into family-mode by default;
generalizable to any custodial relationship.

### N3. Group-key quorum module
General quorum coordination for **any** group's shared key (per D2/D4).
Probably already drafted in `tapit-attest-quorum.zip`. Same code serves
family quorum, parish vestry quorum, town-council quorum.

### N4. Mycelium adapter
A pluggable `WeightTable` provider that lets a wallet declare "I trust
my family at weight 1.0, my town at 0.5, my parish at 0.3," and updates
as those groups publish member rosters. The `WeightTable` is the dial;
the adapter is what loads it from peer/relay sources.

### N5. Supabase adapter
A `SupabaseStore` implementing `AttestationStore`. Stores encrypted
blobs keyed by an opaque wallet ID. Sync via the existing `SyncEngine`.
No server-side decryption capability — the server is dumb storage.

### N6. Peer discovery / transport
Out of scope of the primitive. NFC, QR, email, file. Plus the
relay-pointer mechanism from D8 for groups. See Q3.

### N7. Age / authority policy
"What can a 10-year-old's key sign for?" is policy, not primitive.
Likely implemented as a default `WeightTable` rule that derives weight
from a parent-attested `birthDate` plus the tier of the action.

### N8. Relay (group-hosting) software
Per D8 — a server (or a peer-mode wallet) that:
- Accepts events signed by a configured admission policy.
- Serves public events to anyone, private events to authenticated
  members.
- Publishes (and re-signs) its admission policy as a discoverable event.
- Can be mirrored by anyone.

Likely a thin layer over Supabase or an existing Nostr relay codebase
(`strfry`, etc.).

### N9. Agent layer (premium)
Per D9 — the wallet's AI agent. Open: on-device vs cloud, identity
(does the agent have a key? sign anything?), the bot-to-bot negotiation
protocol, and what guardrails protect the user from a counter-party
agent gaming them. See Q8 and Q9.

### N10. Free-tier library UI
Per D11 — inbox / timeline. Reverse-chronological envelope feed with
search, filter chips, and auto-derived tags (subject, domain, issuer,
tier).

### N11. Charter and admission-event tooling
Per D13 — UI for drafting a group's charter, amending it, recording an
admission decision as a signed event, and (in the agent tier) helping
admins interpret the charter consistently across applicants.

### N12. Group tree library (FROST + MuSig2 + amendment log)
Per D14–D18. The wallet ships a taproot-style group library with:
- Schnorr / FROST / MuSig2 implementations (proven libraries — don't
  roll our own).
- Merkle script-tree construction and Merkle-path verification.
- Per-group key derivation from the master.
- Amendment-log append, verify, and walk-back-to-historical-tree.
- UI surfaces for "groups I'm in", proof-of-membership generation, and
  group-signed envelope verification.

---

## Open questions

Unresolved. Worth chewing on next.

### Q1. ~~NFC interaction model~~ — resolved by D24 + D25
Context-aware tap; tap-to-cosign is a first-class flow.

### Q2. ~~Org identities~~ — resolved by D4
There are no separate org kinds. Orgs are key clusters. `identity` +
`meta` envelopes cover everything.

### Q3. Peer / relay discovery
For a group, D8 says a relay-pointer event signed by the group key. But
how does the user find that pointer in the first place?
- **Social introduction** — a trusted contact shares the group's pubkey
  + pointer via NFC or a signed pointer attestation.
- **Explicit URL/pubkey entry** — for civic orgs that publish theirs on
  their website.
- **DHT** — properly decentralized, heavy. Probably v2.

Likely "social + explicit" for v0.

### Q4. ~~Mycelium weighting defaults~~ — resolved by D26 + D27
Opinionated category defaults at install; 1-hop transitive default
with 0.5 multiplier. Everything editable.

### Q5. Repudiation flow
The primitive marks `repudiate` as v1.1+ (deferred). For mycelium, the
dispute path when a group attestation is challenged by its subject
needs its own design pass before it becomes urgent.

### Q6. ~~Form factor~~ — resolved by D5
Parallel ship: PWA + desktop, one codebase.

### Q7. ~~Free-tier library organization~~ — resolved by D11
Inbox / timeline with tag-based filtering, all items unified.

### Q8. ~~Agent runtime~~ — deferred (D9 revised)
No agent in v1. When/if added, runtime, authority, and disclosure
model become live questions. Until then, parked.

### Q9. ~~Bot-to-bot negotiation protocol~~ — deferred (D9 revised)
No agents → no negotiation. Parked with Q8.

### Q10. ~~Admission-policy schema~~ — resolved by D13 + D19
No schema. Charter is free text; admission is silent-objection window
with signed candidacy + signed admission amendment.

### Q11. ~~Inbox surface~~ — resolved by D11
Unified feed, everything tagged and filterable.

### Q12. ~~Amendment-log hosting~~ — resolved by D20
Same menu as individuals; group chooses.

### Q13. ~~Lost-quorum failure mode~~ — resolved by D21
Accept brick. Remaining members fork a new group and publish a
signed succession claim; continuity is a social/mycelium decision.

### Q14. ~~Charter ↔ tree coupling~~ — resolved by D22
Independent logs. Narrow exception: governance-affecting charter
amendments require quorum signature.

### Q15. ~~Per-group key derivation~~ — resolved by D23
Deterministic path from master seed.

### Q16. Silent-window admission tightening
Per D19:
- How many objections block — single objection (default) or
  threshold-of-objections per charter?
- Who triggers the final amendment-event on window close, and how does
  it satisfy the current tree's quorum rule automatically?

### Q17. Leaf-key rotation slot semantics
Per D23: when a member's leaf in the tree is replaced (compromise,
rotation policy, etc.), how does the derivation path preserve
"restore-from-seed recovers everything"? Lean: bump `member_slot`
deterministically, so the new key is also seed-recoverable. Needs
spec to make sure the slot doesn't have to be remembered out-of-band
(probably derivable from the tree's amendment history, since the
seed-holder can replay it).

---

## Future directions (not v1)

### F1. AI agent layer
Reserved for post-v1. When picked up, must respect: no signing key
(humans always sign); opt-in disclosure of any envelope or library
content sent to the agent; user choice of agent provider (open
interface, not a captive bundle). Bot-to-bot negotiation between
counterparty agents — and its guardrails — designed at that point.

### F2. Charter-evaluation assistance
When an agent layer exists, it's the natural assistant for admins
applying free-text charters (D13) — surfacing precedent, drafting
objections, summarizing candidacies. Not a substitute for human
judgment; an aid to it.

---

## Suggested next moves

In rough order:

1. **Open `tapit-attest-quorum.zip`** to see how much of D2/N3
   (group-key quorum) is already drafted. Cheap, high-info.
2. **Spec the wallet data model** — entities beyond what's in the
   library (`Group`, `Membership`, `RelayPointer`, `Custody`,
   `WeightPolicy`, `Peer`, `TreeAmendment`, `Candidacy`,
   `Objection`). Subject-keyed indexing is load-bearing for D11.
3. **Scaffold the parallel-ship codebase** — React/TS, PWA + Tauri or
   Electron from day one. Pick the desktop shell early so the build
   pipeline isn't a surprise later.
4. **Spec NFC + envelope transport** (Q1).
5. **Spec the taproot-style group library** (N12) — Schnorr / FROST /
   MuSig2 / Merkle tree primitives. Pick proven libraries; don't roll
   our own crypto.
6. **Spec age/authority policy** (N7) — the one piece of "new trust
   logic" rather than UI.

Each can be its own design doc as it gets picked up.
