# SESSION_HANDOFF.md

One-doc summary of the wallet-design work done during the
2026-05-21 session. Copy this file (plus the four listed under
"Files to bring along") into the wallet repo so the next agent
can pick up exactly where we stopped.

## What this session produced

A complete strategy doc and a complete data-model spec for the
Tapit Wallet (Layer 1-2-4 in the CLAUDE.md four-layer
architecture). Layer 3 (Mycelium) stays deferred behind
`MYCELIUM_NETWORK_SPEC.md` per doctrine. No wallet code yet.

The work happened in the wrong repo (this is the `tapit-attest`
library; the wallet is a separate React+Vite codebase that
consumes `tapit-attest/` as a `file:` dep). The deliverables
travel with this handoff to the right home. The library itself
got one correctly-scoped change: a 0.1.1 patch applied from
`tapit-attest-quorum.zip` (misnamed; it was just a sign-poisoning
fix, not quorum code).

## Files to bring along

- `DESIGN.md` — strategy. 27 locked decisions, 5 open questions,
  2 future directions.
- `DATA_MODEL.md` — every wallet entity beyond what the library
  provides. Typescript-flavored sigs. Cross-referenced to
  decisions.
- `HANDOFF.md` — the per-session state-of-the-repo doc (less
  important; the wallet repo will get its own).
- `CLAUDE.md` — already exists in the wallet repo; the version
  here is the same text the operator supplied.

## Locked decisions (D1–D27, one line each)

- D1 Wallets can hold child keypairs in custody (family mode the headline case).
- D2 Groups have their own keys; quorum coordination via a group-key module.
- D3 The library's six attestation kinds + three tiers are the universal envelope.
- D4 Orgs are key clusters, not a separate envelope type.
- D5 Parallel ship: PWA + desktop from one codebase.
- D6 No-coercion: every storage / relay / recovery dependency is user-chosen.
- D7 No Bitcoin script dependency; tap pubs only borrow taproot math.
- D8 Groups publish a signed relay-pointer event for discovery.
- D9 (revised) No AI agent in v1; deferred to Future Directions F1.
- D10 (was renumbered into D9).
- D11 Unified inbox / timeline; everything tagged and filterable.
- D12 (folded into D9) Any future agent never holds a key.
- D13 Charters are free text; no admission-policy DSL.
- D14 Group identity = taproot-style internal key + Merkleized script tree.
- D15 Threshold signatures via FROST (k-of-n) and MuSig2 (n-of-n).
- D16 Signatures verify against the tree active at sign-time.
- D17 Tree amendments form an append-only signed log.
- D18 Default founding is a 1-of-1 single-founder bootstrap; multi-founder ceremonies also supported.
- D19 Admission to existing groups: silent-objection window per charter.
- D20 Group durability picks from the same menu as individuals (local / OTS / relay(s) / paid managed).
- D21 Lost quorum is permanent; remaining members fork and sign a succession claim. No recovery path.
- D22 Charter and tree evolve on independent logs; governance-affecting charter amendments are the narrow exception.
- D23 Per-group leaf keys are deterministically derived from the master seed.
- D24 NFC tap is context-aware; highest-specificity action wins.
- D25 Tap-to-cosign is a first-class flow (two humans, one envelope, one gesture).
- D26 Mycelium ships opinionated category defaults; family 1.0, household 1.0, close-friend 0.8, parish 0.5, civic-org 0.5, acquaintance 0.3, stranger 0.0. Everything editable.
- D27 Transitive trust: 1 hop by default, 0.5x multiplier. Configurable per-edge.

## Still open (Q3, Q5, Q16, Q17, Q18, Q19, Q20, Q21)

- Q3 Peer/relay discovery (leaning social + explicit for v0).
- Q5 Repudiation flow (library has it as v1.1+ slot; design pass when it becomes urgent).
- Q16 Silent-window admission tightening (objection threshold, who triggers the auto-amendment).
- Q17 Leaf-key rotation slot semantics under D23.
- Q18 (from data model) Stranger fallback weight: library `computeWeight` defaults unknown signers to 1; D26 sets `stranger` at 0.0. Lean: add `unknownDefault: number` param to library, wallet passes 0.
- Q19 (from data model) Large-group membership: full leaf list vs root-only with on-demand sibling fetch above some size threshold.
- Q20 (from data model) Inbox-item lifecycle: never auto-archive, rely on filters? Or time-based archive?
- Q21 (from data model) Custody handoff: do prior attestations about the child carry over by default, or does the child opt in per-item?

## Future directions (F1, F2)

- F1 AI agent layer. Reserved for post-v1. If/when picked up: never holds a key, opt-in disclosure, user choice of agent provider.
- F2 Charter-evaluation assistance — natural follow-on once an agent layer exists.

## Picked next track (not started)

After `DATA_MODEL.md` lands in the wallet repo, the next concrete
move is scaffolding the wallet itself per CLAUDE.md (React+Vite,
Tailwind, feature-first `src/features/<slug>/` with `manifest.ts`
and `index.ts` per feature, mobile-first 375px / 44px tap targets,
`tapit-attest` as a `file:` dependency at the repo root, Supabase
encrypted-blob host, Netlify hosting). PHASE 1 of `PLAN.md` (which
exists in the wallet repo) governs the vertical slice; do not
build ten screens before one flow works.

Alternative ready-to-go specs that can come before or in parallel:
- `NFC.md` — wire-level choreography for D24/D25 (frame format,
  draft-hash compare, signature handoff, failure modes).
- `GROUP_TREE.md` — crypto library choices (FROST / MuSig2 on top
  of `@noble/curves`), amendment-event format, script-path
  signature verifier.

## Library state (this repo, not the wallet)

- `tapit-attest` now at 0.1.1.
- Patch: `verifyEnvelope` no longer fails an envelope when one
  appended signature is bad; valid signers are de-duped, invalid
  signers reported but not blocking. Real bug: a relayer appending
  a junk signature could previously invalidate a genuine envelope.
- Tests: 49/49 green; typecheck and lint clean.
- The doctrine claims "Seventy-six tests"; this repo runs 49.
  Either there is a newer library version elsewhere or the doctrine
  count is off. Surfaced for operator confirmation.

## Slips caught and worth carrying forward

1. Q18 (stranger fallback weight) — concrete library API tension
   between `computeWeight` default and D26.
2. Initial DATA_MODEL.md had a typo in the D26 defaults comment
   (`family: 0.0`); fixed to `family: 1.0`.
3. `InboxItem.occurredAt` clarified as local arrival time, not
   the signer's claimed `issuedAt`; otherwise an old envelope
   received today would bury itself in old history.
4. The doctrine requires per-session comms records under
   `appcommander/comms/`; this session did not write them. Not in
   scope for the library repo, but the wallet repo's first
   session should resume the discipline.

## Operator inputs locked during the session

- "No agent now" → D9 revised + F1 future direction.
- "Group durability = same menu as a person" → D20.
- "Group lost quorum: fork the org, can't be faked" → D21.
- "Charter ↔ tree: whichever is best long term" → D22 decoupled.
- "Key derivation: deterministic" → D23.
- "Tap default: context-aware" → D24.
- "Tap-to-cosign: yes" → D25.
- "Mycelium defaults: opinionated, adjust later" → D26.
- "Transitive depth: 1 hop with discount" → D27.

## Where to start in the wallet repo

1. Read `CLAUDE.md`, `DISCOVERY.md`, `PLAN.md` (operator's
   existing wallet-repo docs).
2. Drop `DESIGN.md` and `DATA_MODEL.md` from this handoff into the
   wallet repo at top level (or wherever the wallet repo organizes
   design docs).
3. Reconcile against `DISCOVERY.md` and `PLAN.md` — any
   contradictions between this session's decisions and the
   discovery doc need an operator-confirmed resolution before code.
4. Open the first vertical slice from `PLAN.md` Phase 1, scaffold
   it under `src/features/<slug>/` with `manifest.ts` and
   `index.ts`, gates green from the first commit.
